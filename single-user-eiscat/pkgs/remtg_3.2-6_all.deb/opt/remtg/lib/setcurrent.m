function setcurrent(fig,ax)
set(0,'currentfigure',fig)
set(fig,'currentaxes',ax)
